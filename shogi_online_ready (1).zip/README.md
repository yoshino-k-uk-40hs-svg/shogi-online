# オンライン将棋

`npm install` → `npm start` → `http://localhost:3000`

右上に同じルームコードを入れた2人が接続すると盤面をWebSocketで同期します。

インターネット対戦ではNode.jsを実行できるサーバーへ配置してください。HTTPS環境では自動的にwssを使用します。
